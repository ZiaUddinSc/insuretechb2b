(function($) {
  'use strict';
  if ($("#fileuploader").length) {
    $("#fileuploader").uploadFile({
      url: "YOUR_FILE_UPLOAD_URL",
      fileName: "myfile"
    });
  }
})(jQuery);
(function($) {
  'use strict';
  if ($("#fileuploader1").length) {
    $("#fileuploader1").uploadFile({
      url: "YOUR_FILE_UPLOAD_URL",
      fileName: "myfile"
    });
  }
})(jQuery);
(function($) {
  'use strict';
  if ($("#fileuploader2").length) {
    $("#fileuploader2").uploadFile({
      url: "YOUR_FILE_UPLOAD_URL",
      fileName: "myfile"
    });
  }
})(jQuery);
(function($) {
  'use strict';
  if ($("#fileuploader3").length) {
    $("#fileuploader3").uploadFile({
      url: "YOUR_FILE_UPLOAD_URL",
      fileName: "myfile"
    });
  }
})(jQuery);
(function($) {
  'use strict';
  if ($("#fileuploader4").length) {
    $("#fileuploader4").uploadFile({
      url: "YOUR_FILE_UPLOAD_URL",
      fileName: "myfile"
    });
  }
})(jQuery);
(function($) {
  'use strict';
  if ($("#fileuploader5").length) {
    $("#fileuploader5").uploadFile({
      url: "YOUR_FILE_UPLOAD_URL",
      fileName: "myfile"
    });
  }
})(jQuery);
(function($) {
  'use strict';
  if ($("#fileuploader6").length) {
    $("#fileuploader6").uploadFile({
      url: "YOUR_FILE_UPLOAD_URL",
      fileName: "myfile"
    });
  }
})(jQuery);
(function($) {
  'use strict';
  if ($("#fileuploader7").length) {
    $("#fileuploader7").uploadFile({
      url: "YOUR_FILE_UPLOAD_URL",
      fileName: "myfile"
    });
  }
})(jQuery);
(function($) {
  'use strict';
  if ($("#fileuploader8").length) {
    $("#fileuploader8").uploadFile({
      url: "YOUR_FILE_UPLOAD_URL",
      fileName: "myfile"
    });
  }
})(jQuery);
(function($) {
  'use strict';
  if ($("#fileuploader9").length) {
    $("#fileuploader9").uploadFile({
      url: "YOUR_FILE_UPLOAD_URL",
      fileName: "myfile"
    });
  }
})(jQuery);